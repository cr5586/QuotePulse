# QuotePulse Global Summary

- **Total Unique Quotes:** 100

## Top 10 Authors
- Albert Einstein: 10 quotes
- J.K. Rowling: 9 quotes
- Marilyn Monroe: 7 quotes
- Dr. Seuss: 6 quotes
- Mark Twain: 6 quotes
- Jane Austen: 5 quotes
- C.S. Lewis: 5 quotes
- Bob Marley: 3 quotes
- Eleanor Roosevelt: 2 quotes
- Ralph Waldo Emerson: 2 quotes

## Top 10 Tags
- love: 14 occurrences
- inspirational: 13 occurrences
- life: 13 occurrences
- humor: 12 occurrences
- books: 11 occurrences
- reading: 7 occurrences
- friendship: 5 occurrences
- friends: 4 occurrences
- truth: 4 occurrences
- simile: 3 occurrences
